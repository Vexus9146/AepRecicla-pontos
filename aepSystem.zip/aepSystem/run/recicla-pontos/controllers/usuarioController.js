// controllers/usuarioController.js
const storage = require('../data/storage');
const { calcularPontos, calcularValorResgate } = require('../services/pontuacaoService');

// Cadastrar usuário
function cadastrarUsuario(req, res) {
  const { nome, cpf } = req.body;

  if (!nome || !cpf) {
    return res.status(400).json({ mensagem: 'Nome e CPF são obrigatórios.' });
  }

  const existente = storage.usuarios.find(u => u.cpf === cpf);
  if (existente) {
    return res.status(409).json({ mensagem: 'Usuário já cadastrado.' });
  }

  const novoUsuario = { nome, cpf, pontos: 0, historico: [] };
  storage.usuarios.push(novoUsuario);

  return res.status(201).json({ mensagem: 'Usuário cadastrado com sucesso.', usuario: novoUsuario });
}

// Adicionar pontos por tipo de lixo
function adicionarPontos(req, res) {
  const { cpf } = req.params;
  const { tipoLixo, quantidade } = req.body;

  if (!tipoLixo || !quantidade) {
    return res.status(400).json({ mensagem: 'Tipo de lixo e quantidade são obrigatórios.' });
  }

  const usuario = storage.usuarios.find(u => u.cpf === cpf);
  if (!usuario) {
    return res.status(404).json({ mensagem: 'Usuário não encontrado.' });
  }

  const pontosGanhos = calcularPontos(tipoLixo, quantidade);
  if (pontosGanhos === null) {
    return res.status(400).json({ mensagem: 'Tipo de lixo inválido.' });
  }

  usuario.pontos += pontosGanhos;
  usuario.historico.push({
    tipoLixo,
    quantidade,
    pontosGanhos,
    data: new Date().toISOString()
  });

  return res.json({
    mensagem: `Adicionados ${pontosGanhos} pontos ao usuário ${usuario.nome}.`,
    pontosTotais: usuario.pontos
  });
}

// Resgatar pontos
function resgatarPontos(req, res) {
  const { cpf } = req.params;
  const { pontosParaTrocar } = req.body;

  if (!pontosParaTrocar) {
    return res.status(400).json({ mensagem: 'Quantidade de pontos para trocar é obrigatória.' });
  }

  const usuario = storage.usuarios.find(u => u.cpf === cpf);
  if (!usuario) {
    return res.status(404).json({ mensagem: 'Usuário não encontrado.' });
  }

  if (pontosParaTrocar > usuario.pontos) {
    return res.status(400).json({ mensagem: 'Usuário não tem pontos suficientes.' });
  }

  const valor = calcularValorResgate(pontosParaTrocar);
  usuario.pontos -= pontosParaTrocar;

  usuario.historico.push({
    tipoLixo: 'resgate',
    quantidade: 0,
    pontosGanhos: -pontosParaTrocar,
    valorRecebido: valor,
    data: new Date().toISOString()
  });

  return res.json({
    mensagem: `Usuário ${usuario.nome} resgatou R$ ${valor.toFixed(2)} por ${pontosParaTrocar} pontos.`,
    pontosRestantes: usuario.pontos
  });
}

// Listar todos os usuários
function listarUsuarios(req, res) {
  return res.json(storage.usuarios);
}

// Buscar usuário por CPF
function buscarPorCPF(req, res) {
  const { cpf } = req.params;
  const usuario = storage.usuarios.find(u => u.cpf === cpf);
  if (!usuario) {
    return res.status(404).json({ mensagem: 'Usuário não encontrado.' });
  }
  return res.json(usuario);
}

// Buscar usuários por nome (parcial)
function buscarPorNome(req, res) {
  const { nome } = req.params;
  const resultados = storage.usuarios.filter(u =>
    u.nome.toLowerCase().includes(nome.toLowerCase())
  );
  return res.json(resultados);
}

// Atualizar nome do usuário
function atualizarUsuario(req, res) {
  const { cpf } = req.params;
  const { nome } = req.body;

  const usuario = storage.usuarios.find(u => u.cpf === cpf);
  if (!usuario) {
    return res.status(404).json({ mensagem: 'Usuário não encontrado.' });
  }

  if (!nome) {
    return res.status(400).json({ mensagem: 'Novo nome é obrigatório.' });
  }

  usuario.nome = nome;
  return res.json({ mensagem: 'Nome atualizado com sucesso.', usuario });
}

// Deletar usuário
function deletarUsuario(req, res) {
  const { cpf } = req.params;
  const index = storage.usuarios.findIndex(u => u.cpf === cpf);
  if (index === -1) {
    return res.status(404).json({ mensagem: 'Usuário não encontrado.' });
  }

  storage.usuarios.splice(index, 1);
  return res.json({ mensagem: 'Usuário removido com sucesso.' });
}

module.exports = {
  cadastrarUsuario,
  adicionarPontos,
  resgatarPontos,
  listarUsuarios,
  buscarPorCPF,
  buscarPorNome,
  atualizarUsuario,
  deletarUsuario
};
