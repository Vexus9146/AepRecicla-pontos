const form = document.getElementById('formCadastro');
const nomeInput = document.getElementById('nome');
const cpfInput = document.getElementById('cpf');
const lista = document.getElementById('listaUsuarios');
const mensagem = document.getElementById('mensagem');

form.addEventListener('submit', async (e) => {
  e.preventDefault();

  const nome = nomeInput.value.trim();
  const cpf = cpfInput.value.trim();

  if (!nome || !cpf) return;

  const res = await fetch('http://localhost:3000/usuarios', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ nome, cpf })
  });

  const data = await res.json();
  mensagem.textContent = data.mensagem;

  if (res.ok) {
    nomeInput.value = '';
    cpfInput.value = '';
    carregarUsuarios();
  }
});

async function carregarUsuarios() {
  lista.innerHTML = '';
  const res = await fetch('http://localhost:3000/usuarios');
  const usuarios = await res.json();

  usuarios.forEach(u => {
    const li = document.createElement('li');
    li.textContent = `${u.nome} - CPF: ${u.cpf} - Pontos: ${u.pontos} `;

    const botaoExcluir = document.createElement('button');
    botaoExcluir.textContent = 'Excluir';
    botaoExcluir.style.marginLeft = '10px';
    botaoExcluir.onclick = () => excluirUsuario(u.cpf);

    li.appendChild(botaoExcluir);
    lista.appendChild(li);
  });
}

async function excluirUsuario(cpf) {
  const confirmacao = confirm('Tem certeza que deseja remover este usuário?');
  if (!confirmacao) return;

  const res = await fetch(`http://localhost:3000/usuarios/${cpf}`, {
    method: 'DELETE'
  });

  const data = await res.json();
  mensagem.textContent = data.mensagem;

  if (res.ok) carregarUsuarios();
}

carregarUsuarios();
