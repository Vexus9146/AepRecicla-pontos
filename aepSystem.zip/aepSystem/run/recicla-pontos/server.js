// server.js
const express = require('express');
const app = express();

const usuariosRoutes = require('./routes/usuarios');
const descartesRoutes = require('./routes/descartes'); // ✅ Importação adicionada

// Middleware para interpretar JSON no corpo da requisição
app.use(express.json());

const cors = require('cors');
app.use(cors());

app.use('/usuarios', usuariosRoutes);
app.use('/descartes', descartesRoutes); // ✅ Registro da rota

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
