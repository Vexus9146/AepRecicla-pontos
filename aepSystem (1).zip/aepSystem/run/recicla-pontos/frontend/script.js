async function cadastrarUsuario() {
  const nome = document.getElementById('nome').value;
  const cpf = document.getElementById('cpf').value;

  const res = await fetch('http://localhost:3000/usuarios', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ nome, cpf })
  });

  const data = await res.json();
  alert(data.mensagem || JSON.stringify(data));
}

async function registrarDescarte() {
  const cpf = document.getElementById('cpfDescarte').value;
  const tipoLixo = document.getElementById('tipoLixo').value;
  const quantidade = parseInt(document.getElementById('quantidadeLixo').value);

  const res = await fetch(`http://localhost:3000/usuarios/${cpf}/adicionar-pontos`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ tipoLixo, quantidade })
  });

  const data = await res.json();
  alert(data.mensagem || JSON.stringify(data));
}

async function resgatarPontos() {
  const cpf = document.getElementById('cpfResgate').value;
  const pontosParaTrocar = parseInt(document.getElementById('pontosParaTrocar').value);

  const res = await fetch(`http://localhost:3000/usuarios/${cpf}/resgatar`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ pontosParaTrocar })
  });

  const data = await res.json();
  alert(data.mensagem || JSON.stringify(data));
}

async function listarUsuarios() {
  const res = await fetch('http://localhost:3000/usuarios');
  const usuarios = await res.json();

  const container = document.getElementById('usuariosContainer');
  container.innerHTML = '';

  usuarios.forEach(u => {
    const li = document.createElement('li');
    li.innerHTML = `<strong>${u.nome}</strong><br>CPF: ${u.cpf}<br>Pontos: ${u.pontos}`;
    container.appendChild(li);
  });
}
