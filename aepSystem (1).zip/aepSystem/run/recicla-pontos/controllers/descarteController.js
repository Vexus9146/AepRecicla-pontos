const storage = require('../data/storage');
const { calcularPontos } = require('../services/pontuacaoService');

// Listar todos os descartes
function listarTodosDescartes(req, res) {
  const todos = storage.usuarios.flatMap(u =>
    u.historico.map((h, i) => ({ cpf: u.cpf, nome: u.nome, index: i, ...h }))
  );
  return res.json(todos);
}

// Listar descartes de um usuário
function listarDescartesPorUsuario(req, res) {
  const { cpf } = req.params;
  const usuario = storage.usuarios.find(u => u.cpf === cpf);
  if (!usuario) {
    return res.status(404).json({ mensagem: 'Usuário não encontrado.' });
  }
  return res.json(usuario.historico);
}

// Registrar novo descarte
function registrarDescarte(req, res) {
  const { cpf } = req.params;
  const { tipoLixo, quantidade } = req.body;

  const usuario = storage.usuarios.find(u => u.cpf === cpf);
  if (!usuario) {
    return res.status(404).json({ mensagem: 'Usuário não encontrado.' });
  }

  const pontos = calcularPontos(tipoLixo, quantidade);
  if (pontos === null) {
    return res.status(400).json({ mensagem: 'Tipo de lixo inválido.' });
  }

  usuario.pontos += pontos;

  const registro = {
    tipoLixo,
    quantidade,
    pontosGanhos: pontos,
    data: new Date().toISOString()
  };

  usuario.historico.push(registro);
  return res.status(201).json({ mensagem: 'Descarte registrado com sucesso.', registro });
}

// Atualizar descarte
function atualizarDescarte(req, res) {
  const { cpf, index } = req.params;
  const { tipoLixo, quantidade } = req.body;

  const usuario = storage.usuarios.find(u => u.cpf === cpf);
  if (!usuario || !usuario.historico[index]) {
    return res.status(404).json({ mensagem: 'Usuário ou descarte não encontrado.' });
  }

  const antigo = usuario.historico[index];
  usuario.pontos -= antigo.pontosGanhos;

  const novosPontos = calcularPontos(tipoLixo, quantidade);
  if (novosPontos === null) {
    return res.status(400).json({ mensagem: 'Tipo de lixo inválido.' });
  }

  const novoRegistro = {
    tipoLixo,
    quantidade,
    pontosGanhos: novosPontos,
    data: new Date().toISOString()
  };

  usuario.historico[index] = novoRegistro;
  usuario.pontos += novosPontos;

  return res.json({ mensagem: 'Descarte atualizado.', novoRegistro });
}

// Deletar descarte
function deletarDescarte(req, res) {
  const { cpf, index } = req.params;
  const usuario = storage.usuarios.find(u => u.cpf === cpf);
  if (!usuario || !usuario.historico[index]) {
    return res.status(404).json({ mensagem: 'Usuário ou descarte não encontrado.' });
  }

  const removido = usuario.historico.splice(index, 1)[0];
  usuario.pontos -= removido.pontosGanhos;

  return res.json({ mensagem: 'Descarte removido com sucesso.', removido });
}

module.exports = {
  listarTodosDescartes,
  listarDescartesPorUsuario,
  registrarDescarte,
  atualizarDescarte,
  deletarDescarte
};
