const express = require('express');
const router = express.Router();
const controller = require('../controllers/descarteController');

router.get('/', controller.listarTodosDescartes);
router.get('/:cpf', controller.listarDescartesPorUsuario);
router.post('/:cpf', controller.registrarDescarte);
router.put('/:cpf/:index', controller.atualizarDescarte);
router.delete('/:cpf/:index', controller.deletarDescarte);

module.exports = router;
