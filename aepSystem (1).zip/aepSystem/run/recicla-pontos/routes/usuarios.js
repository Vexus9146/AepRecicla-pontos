// routes/usuarios.js
const express = require('express');
const router = express.Router();
const controller = require('../controllers/usuarioController');

router.get('/', controller.listarUsuarios);
router.get('/:cpf', controller.buscarPorCPF);
router.get('/nome/:nome', controller.buscarPorNome);
router.put('/:cpf', controller.atualizarUsuario);
router.delete('/:cpf', controller.deletarUsuario);

router.post('/', controller.cadastrarUsuario);
router.post('/:cpf/adicionar-pontos', controller.adicionarPontos);
router.post('/:cpf/resgatar', controller.resgatarPontos);

module.exports = router;
