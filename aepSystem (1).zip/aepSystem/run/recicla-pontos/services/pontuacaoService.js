// services/pontuacaoService.js
const pontosPorTipo = {
  lata: 10,
  caixa: 5,
  vidro: 8,
  plastico: 7,
  papel: 4,
  eletronico: 20,
  pilha: 30
};

function calcularPontos(tipoLixo, quantidade) {
  const tipo = tipoLixo.toLowerCase();
  const pontos = pontosPorTipo[tipo];
  if (!pontos) return null;
  return pontos * quantidade;
}

function calcularValorResgate(pontos) {
  const valorPor300 = 5.0;
  return (pontos / 300) * valorPor300;
}

module.exports = {
  calcularPontos,
  calcularValorResgate
};
