// data/storage.js
const usuarios = [];

module.exports = { usuarios };

  